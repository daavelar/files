<?php

return [
    'driver' => env('BROKER_DRIVER', 'log'),

    'host' => env('BROKER_HOST'),

    'username' => env('BROKER_USERNAME'),
];

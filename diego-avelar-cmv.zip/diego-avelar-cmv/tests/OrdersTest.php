<?php

namespace Tests\Feature;

use App\Models\Store;
use Illuminate\Support\Str;
use Junges\Kafka\Facades\Kafka;
use Mockery\Mock;
use Tests\TestCase;
use Tests\Traits\DropCollections;

class OrdersTest extends TestCase
{
    use DropCollections;

    public function test_intelipost_orders_can_be_created()
    {
        Kafka::fake();

        Store::create([
            'customer' => 'intelipost',
            'name' => 'Carrefour Uberlândia',
            'slug' => 'carrefour-uberlandia',
            'rules' => [
                'origin_name' => 'required|unique:orders_carrefour-uberlandia'
            ],
            'capture_integrations' => [
                ['format' => 'intelipost', 'protocol' => 'https']
            ],
        ]);

        $mockedValue = '123456';

        $mock = $this->mock(Str::class);
        $mock->shouldReceive('orderedUuid')->twice()->andReturn($mockedValue);

        $orderStub = json_decode(stubs_path('intelipost.json'), true);

        $response = $this->post('api/orders/carrefour-uberlandia', $orderStub, ['accept' => 'application/json']);

       $response->assertJson([
           'number' => $mockedValue,
           'tracking_code' => $mockedValue
       ]);
    }
}

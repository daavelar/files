<?php

namespace App\Repositories\Mongodb\Orders;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class OrdersRepository
{
    public function save($collection, array $data)
    {
        $data = array_merge($data, ['number' => (string)Str::orderedUuid(), 'tracking_code' => (string)Str::orderedUuid()]);

        DB::collection('orders_' . $collection)->insert($data);

        return $data;
    }
}

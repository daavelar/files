<?php

namespace App\Repositories\Mongodb\Stores;

use App\Models\Store;

class StoresRepository implements StoresRepositoryContract
{
    public function fetchBySlug(string $slug)
    {
        return Store::whereSlug($slug)->firstOrFail();
    }
}

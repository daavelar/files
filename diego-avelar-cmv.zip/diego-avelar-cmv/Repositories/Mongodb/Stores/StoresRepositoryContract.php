<?php

namespace App\Repositories\Mongodb\Stores;

interface StoresRepositoryContract
{
    public function fetchBySlug(string $slug);
}
